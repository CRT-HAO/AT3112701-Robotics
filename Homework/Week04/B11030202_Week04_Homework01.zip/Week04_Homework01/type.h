#pragma once

#include <Arduino.h>

typedef struct {
  uint64_t time;
  String text;
} LyricData;